#!/bin/bash

java -jar Geyser.jar

read -p "Press [ENTER] To Continue" pause
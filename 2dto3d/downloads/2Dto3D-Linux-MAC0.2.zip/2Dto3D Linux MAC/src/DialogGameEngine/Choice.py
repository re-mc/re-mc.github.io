#Assign Variables
Choices = []
SelectedOption = 0

def Add(Choice):
    global Choices
    Choices.append(Choice)

def Give():
    global Choices
    print('[Options]')
    x = 0
    for i in Choices:
        x += 1
        print(f'[{x}] "{i}"')
    takeinput = input('What will it be? >>')
    num = 0
    while num < x:
        num += 1
        inputnum = int(takeinput)
        if inputnum == num:
            global SelectedOption
            SelectedOption = num







def reset():
    global Choices
    Choices = []
    global SelectedOption
    SelectedOption = 0
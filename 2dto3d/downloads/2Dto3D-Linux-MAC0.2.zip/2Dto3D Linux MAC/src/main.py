from ursina import *
from DialogGameEngine import Dialog
import time

app = Ursina()

ClickAction = 'default'

door_texture = load_texture('Assets/Door.png')
attack_sound = Audio('Assets/Sound/Attack.ogg', loop=False, autoplay=False)

door = Entity(model='quad', texture=door_texture, position=(3, 2), scale=(1, 2), collider='box', double_sided=True)
displaytxt = Text(text='Test', position=(-.85, -.45), color=color.white)

AbilityCoolDown = False
speed = 0
playerspeed = 0
Ability1 = False

window.fps_counter.enabled = False



RedCubes = []
CubesDestroyed = 0


class RedCube(Button):
    Health = 10
    health_modifier = 1
    cubespeed = 2
    TakeDamage = False
    DamageModifier = 1
    ThreeD = False

    def __init__(self):
        super().__init__(
            parent=scene,
            model='quad',
            texture='white_cube',
            color=color.red,
            scale=(1, 1),
            collider='box',
            tooltip=Tooltip("?"),
            position=(0,0),
            double_sided=True,
        )

    def input(self, key):
        if self.hovered:
            if key == 'left mouse down':
                self.TakeDamage = True



class Player(Button):

    Speed = 5
    def __init__(self):
        super().__init__(
            parent=scene,
            model='cube',
            texture='white_cube',
            color=color.orange,
            scale=(1, 2),
            collider='box',
        )

    def input(self, key):
        if self.hovered:
            global ClickAction
            if key == 'left mouse down':
                if ClickAction == 'default':
                    Dialog.SendMod("Hello!", "Player")
                    SendDialog()
                elif ClickAction == 'Room2':
                    Dialog.SendMod("Where am I?", "Player")
                    SendDialog()
                    ClickAction = 'Room2D1'
                elif ClickAction == 'Room2D1':
                    Dialog.SendMod("I Don't Like This Place.", "Player")
                    SendDialog()
                    ClickAction = 'Room2D2'
                elif ClickAction == 'Room2D2':
                    global CubesDestroyed
                    CubesDestroyed = 0
                    redcube = RedCube()
                    global RedCubes
                    RedCubes.append(redcube)
                    ClickAction = 'Room2D3'
                elif ClickAction == 'Room2D3':
                    if CubesDestroyed >= 1:
                        redcube1 = RedCube()
                        RedCubes.append(redcube1)

                        redcube2 = RedCube()
                        redcube2.position = (0,-2)
                        redcube2.Health = 15
                        RedCubes.append(redcube2)
                        redcube3 = RedCube()
                        redcube3.position = (0,2)
                        redcube3.Health = 20
                        RedCubes.append(redcube3)
                    if CubesDestroyed >= 9:
                        ClickAction = 'Room3'
                        Dialog.SendMod("Challenge Completed!", "Door")
                        SendDialog()
                        door.enabled = True
                        door.position = (10, 0)

                elif ClickAction == 'Room3':
                    redcube1 = RedCube()
                    redcube1.Health = 25
                    RedCubes.append(redcube1)
                    redcube2 = RedCube()
                    redcube2.position = (0, -2)
                    redcube2.Health = 5
                    RedCubes.append(redcube2)
                    redcube3 = RedCube()
                    redcube3.position = (0, 2)
                    redcube3.Health = 20
                    RedCubes.append(redcube3)
                    if CubesDestroyed >= 6:
                        redcube3d1 = RedCube()
                        redcube3d1.Health = 2
                        redcube3d1.position = (2,0,2)
                        redcube3d1.model = 'cube'
                        redcube3d1.ThreeD = True
                        RedCubes.append(redcube3d1)

                        redcube1.Health = 10
                        redcube2.Health = 5
                        redcube3.Health = 1
                        if CubesDestroyed >= 17:
                            redcube3d2 = RedCube()
                            redcube3d2.Health = 2
                            redcube3d2.position = (-2,2,-2)
                            redcube3d2.model = 'cube'
                            redcube3d2.ThreeD = True
                            RedCubes.append(redcube3d2)
                        if CubesDestroyed >= 22:
                            redcube3d3 = RedCube()
                            redcube3d3.Health = 1
                            redcube3d3.position = (0,-4,1)
                            redcube3d3.model = 'cube'
                            redcube3d3.ThreeD = True
                            RedCubes.append(redcube3d3)
                            if CubesDestroyed >= 27:
                                redcube1.position = (10,10)
                                redcube3d2.position = (-10,10,4)
                                Dialog.SendMod("Hey, why am i doing this?", "Player")
                                SendDialog()
                                if CubesDestroyed >= 35:
                                    Dialog.SendMod("I'm Tired Of This.", "Player")
                                    SendDialog()
                                    ClickAction = 'Room3D1'
                elif ClickAction == 'Room3D1':
                    Dialog.SendMod("Press The 1 Key!, I've Got Something For You...", "AI")
                    SendDialog()
                    global Ability1
                    Ability1 = True
                    redcube1 = RedCube()
                    redcube1.cubespeed *= 1.4
                    redcube1.position = (player.x,player.y-6)
                    RedCubes.append(redcube1)





player = Player()


def SendDialog():
    global displaytxt
    displaytxt.text = Dialog.GameDialog


Dialog.Create('message', "Click Me For Dialog!, Also Press SHIFT + Q To Exit The Game.")
Dialog.Mod('message', "Player")
SendDialog()


def update():  # update gets automatically called.

    if held_keys['left arrow']:
        player.x -= 5 * time.dt
    if held_keys['right arrow']:
        player.x += 5 * time.dt
    if held_keys['up arrow']:
        player.y += 5 * time.dt
    if held_keys['down arrow']:
        player.y -= 5 * time.dt

    pcollide = player.intersects()

    if pcollide.hit:
        Dialog.Create('message', "Enter Door? (Press Space)")
        Dialog.Mod('message', "Player")
        SendDialog()
        if held_keys['space']:
            door.enabled = False
            Dialog.SendMod("New Room!", "Door")
            SendDialog()
            global ClickAction
            if ClickAction == 'default':

                ClickAction = 'Room2'
            elif ClickAction == 'Room3':
                global RedCubes
                for cube in RedCubes:
                    destroy(cube)
                    RedCubes = []
                    global CubesDestroyed
                    CubesDestroyed = 0

                ClickAction = 'Room3'
    for cube in RedCubes:
        global AbilityCoolDown
        cubespeed = cube.cubespeed

        for cube2 in RedCubes:
            if not cube == cube2:
                if cube.intersects() and cube.intersects().entity == cube2:
                    if cube.x < cube2.x:
                        cube.x -= cubespeed * time.dt
                    if cube.x > cube2.x:
                        cube.x += cubespeed * time.dt
                    if cube.y < cube2.y:
                        cube.y -= cubespeed * time.dt
                    if cube.y > cube2.y:
                        cube.y += cubespeed * time.dt
                else:
                    if cube.x < player.x:
                        cube.x += cubespeed * time.dt
                    if cube.x > player.x:
                        cube.x -= cubespeed * time.dt
                    if cube.y < player.y:
                        cube.y += cubespeed * time.dt
                    if cube.y > player.y:
                        cube.y -= cubespeed *time.dt
                    if cube.ThreeD:
                        if cube.z < player.z:
                            cube.z += cubespeed * time.dt
                        if cube.z > player.z:
                            cube.z -= cubespeed * time.dt

        if len(RedCubes) == 1:
            if cube.x < player.x:
                cube.x += cubespeed * time.dt
            if cube.x > player.x:
                        cube.x -= cubespeed * time.dt
            if cube.y < player.y:
                cube.y += cubespeed * time.dt
            if cube.y > player.y:
                cube.y -= cubespeed * time.dt
            if cube.ThreeD:
                if cube.z < player.z:
                    cube.z += cubespeed * time.dt
                if cube.z > player.z:
                    cube.z -= cubespeed * time.dt


        Ccollide = cube.intersects()


        if Ccollide:
            if player.intersects().entity == cube:
                exit('You Died!')
        if cube.TakeDamage:
            cube.Health -= cube.health_modifier
            cube.tooltip.text = str(cube.Health)
            attack_sound.play()

            cube.TakeDamage = False
            if cube.Health <= 0:
                destroy(cube)
                CubesDestroyed += 1
                RedCubes.remove(cube)
                AbilityCoolDown = False
        if held_keys['shift'] and not AbilityCoolDown:
            for AbliltyCube in RedCubes:
                AbliltyCube.Health -= 5
            AbilityCoolDown = True
            attack_sound.play()
        if held_keys['/'] and not AbilityCoolDown:
            for AbliltyCube in RedCubes:
                global speed
                speed = AbliltyCube.cubespeed
                AbliltyCube.cubespeed /= 2
            AbilityCoolDown = True
        if not AbilityCoolDown and speed is not 0:
            for AbliltyCube in RedCubes:
                AbliltyCube.cubespeed = speed

    global playerspeed
    if held_keys['1'] and not AbilityCoolDown and Ability1:
        playerspeed = player.Speed
        player.Speed *= 8
        AbilityCoolDown = True
        attack_sound.play()
    if not AbilityCoolDown and playerspeed is not 0:
        player.Speed = playerspeed

EditorCamera()

app.run()

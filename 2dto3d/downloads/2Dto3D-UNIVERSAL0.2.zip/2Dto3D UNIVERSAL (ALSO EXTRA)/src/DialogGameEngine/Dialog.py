dialogs = []
GameDialog = 'None'
TryVar = 0


#Dialog Assigner

def Create(DialogType, DialogMessage, id=0):
    if DialogType == 'message':
        global GameDialog
        GameDialog = DialogMessage
    elif DialogType == 'saved':
        try:
            TryVar = id
        except:
            print('Must Have three arguments for Dialog Saved')
            exit()
        dialogs[id] = DialogMessage

#Dialog Printer

# Dialog.Create('<message, saved>', '<Person>', <id>)

def Print(DialogType, Player, id=0):
    if DialogType == 'message':
        print(f'[{Player}]: {GameDialog}')
    elif DialogType == 'saved':
        print(f'[{Player}]: {dialogs[id]}')

def Mod(DialogType, Player, id=0):
    global GameDialog
    if DialogType == 'message':
        GameDialog = (f'[{Player}]: {GameDialog}')
    elif DialogType == 'saved':
        GameDialog = (f'[{Player}]: {dialogs[id]}')


def Send(DialogMessage, Player):
    Create('message', DialogMessage)
    Print('message', Player)

def SendMod(DialogMessage, Player):
    Create('message', DialogMessage)
    Mod('message', Player)

you may need to open terminal and type

chmod +x Game.sh

to execute script
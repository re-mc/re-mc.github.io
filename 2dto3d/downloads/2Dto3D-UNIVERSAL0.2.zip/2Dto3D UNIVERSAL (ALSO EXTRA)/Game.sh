#!bin/bash

while [ true ]; do
	python3 src/main.py
	read -p "Press [ENTER] To Restart Game!" regame
done